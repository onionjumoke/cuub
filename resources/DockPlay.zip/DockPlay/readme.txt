readme.txt

Hello, this is a simple guide to, well, guide you on the DockPlay tweak installation process.
Step 1: Assuming you didn’t run DockAssistant, run it. You can get it on the cuub tweak manager. It allows you to create a wallpaper with a dock that will never change its color, perfect for any dock-related tweaks.
Step 2: Install all the shortcuts in this .zip, they will be the ones performing the actions.
Step 3, Add all of these shortcuts to your homescreen, but before adding them, change their icons to the ones inside this zip. I suggest extracting everything before doing anything.
Step 4: Just move your new icons into your dock and you’ll be done.