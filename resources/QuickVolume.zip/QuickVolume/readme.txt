readme.txt

Tutorial
Step 1, install the shortcut
Step 2, save the icon provided in this zip
Step 3, add the shortcut to the home screen and change the icon to the provided one.
